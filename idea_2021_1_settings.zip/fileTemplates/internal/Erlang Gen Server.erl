#parse("Erlang File Header.erl")
-module(${NAME_ATOM}).
#parse("Erlang File Module.erl")

-behaviour(gen_server_game).

-include("common.hrl").

-record(state, {timer_list}).

-export([start_link/0, do_init/1, do_call/3, do_cast/2, do_info/2, do_terminate/2]).

%%------------------------------------------
%% @doc 启动接口
%%------------------------------------------
start_link() ->
    gen_server_game:start_link({local, ?MODULE}, ?MODULE, [], []).

%%------------------------------------------
%% @doc 初始化逻辑
%%------------------------------------------
do_init([]) ->
    State = #state{},
    {ok, State}.

%%------------------------------------------
%% @doc CALL 消息处理
%%------------------------------------------
do_call(_Msg, _From, State) ->
    ?DEBUG(" msg no match ~p~n", [_Msg]),
    {reply, ok, State}.

%%------------------------------------------
%% @doc CAST 消息处理
%%------------------------------------------
do_cast(_Msg, State) ->
    ?DEBUG(" msg no match ~p~n", [_Msg]),
    {noreply, State}.

%%------------------------------------------
%% @doc INFO 消息处理
%%------------------------------------------
do_info(_Msg, State) ->
    ?DEBUG(" msg no match ~p~n", [_Msg]),
    {noreply, State}.

%%------------------------------------------
%% @doc 服务器停止
%%------------------------------------------
do_terminate(_R, _State) ->
    ok.
