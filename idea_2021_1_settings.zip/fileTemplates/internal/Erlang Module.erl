#parse("Erlang File Header.erl")
-module(${NAME_ATOM}).
#parse("Erlang File Module.erl")
%% API
-export([

    ]
).

-include("common.hrl").

%%------------------------------------------
%% @doc
%%------------------------------------------